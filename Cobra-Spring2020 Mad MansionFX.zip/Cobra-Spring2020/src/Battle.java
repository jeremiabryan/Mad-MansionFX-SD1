
public interface Battle {

}
