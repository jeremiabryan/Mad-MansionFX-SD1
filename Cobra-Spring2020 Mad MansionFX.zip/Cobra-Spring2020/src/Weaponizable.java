
public interface Weaponizable {
	
	boolean attack();
	boolean runaway();
	boolean dealDamage();
	boolean Encounter();
	

}
