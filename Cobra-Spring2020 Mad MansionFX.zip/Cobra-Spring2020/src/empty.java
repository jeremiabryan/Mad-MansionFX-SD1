
public class empty {
	public static void main (String [] args) {
		System.out.println("HOLA");
		System.out.println("Hello, hello, hello!");
		System.out.println("Bonjour!");
		System.out.println("2nd!");
	}
}
