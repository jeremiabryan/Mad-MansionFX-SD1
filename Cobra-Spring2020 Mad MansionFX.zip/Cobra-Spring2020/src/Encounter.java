
public abstract class Encounter {
	

}
